
The images will need to have the folder added before the imaage name in the HTML file. 
Add multiple cursors by holding down the ALT key and clicking where you want the cursors.  That way you only need the type the folder name once.